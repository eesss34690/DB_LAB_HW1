SELECT COUNT(champion_id) AS cnt
FROM champ;
